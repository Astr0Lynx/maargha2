// GPSInfo.cpp: implementation of the GPSInfo class.
//
//////////////////////////////////////////////////////////////////////
#include "GPSProcessing.h"
#include <deque>

//Global Variables
static bool switchOFF;
extern std::deque<loc>gpsTrack;

loc lastPOS;	

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GPSProcessing::GPSProcessing()
{}

GPSProcessing::~GPSProcessing()
{}


Point2d GPSProcessing::tngtPlaneProj(loc mapCenter,loc ltlnPt)
{
	Point2d tmploc;
    tmploc.x = 51500 * (-mapCenter.lon +ltlnPt.lon);
	tmploc.y = 51500 * (mapCenter.lat -ltlnPt.lat);//assume earth is flat in the small FOV. the difference is multiplied with scale factor..
	//the above formula will work only in the northern hemisphere and east of meridian
	return tmploc;
}
double gpsDistance1(loc presPOS, loc prevPOS) 
{
	if((presPOS.lat == prevPOS.lat) && (presPOS.lon == prevPOS.lon))
		return 0;
    double earthRadius = 6371; //kilometers
	double dLat = DEG2RAD((prevPOS.lat-presPOS.lat));
    double dLng = DEG2RAD((prevPOS.lon-presPOS.lon));
    double a = sin(dLat/2) * sin(dLat/2) +
               cos(DEG2RAD(presPOS.lat)) * cos(DEG2RAD(prevPOS.lat)) *
               sin(dLng/2) * sin(dLng/2);
    double c = 2 * atan2(sqrt(a), sqrt(1-a));
    double dist = (earthRadius * c);
    return dist*1000;
}


void GPSProcessing::latlon2Cart_mlti_pt(vector <loc> *wayPts,vector <vector<loc>> *wayGrp,vector <Point2f> *cartWayPts,vector <vector<Point2f>> *cartWayPtsGrp,loc mapCenter)
{
	Point2f cartWayPt;
	for(unsigned int i =0; i < wayGrp->size(); i++)
	{
		for(unsigned int j = 0; j< wayGrp->at(i).size(); j++)
		{
			double d = gpsDistance1(mapCenter,wayGrp->at(i).at(j));
			if(d>1000.0)//only points within 1 km radius is drawn on the map
				continue;
			cartWayPt = tngtPlaneProj(mapCenter,wayGrp->at(i).at(j));
			cartWayPts->push_back(cartWayPt);
		}
		if(!cartWayPts->empty())
			cartWayPtsGrp->push_back(*cartWayPts);
		cartWayPts->clear();
	}
}

Point2d GPSProcessing::latlon2Cart_1_pt(loc ltlnPt,loc mapCenter)
{
	Point2d tmploc;
    tmploc.x = 51500 * (-mapCenter.lon +ltlnPt.lon);
	tmploc.y = 51500 * (mapCenter.lat -ltlnPt.lat);//assume earth is flat in the small FOV. the difference is multiplied with scale factor..
	//the above formula will work only in the northern hemisphere and east of meridian
	return tmploc;
}


void GPSProcessing::mapRead(vector <loc> *wayPts,vector <vector<loc>> *wayPtsGrp)
{
	loc tmpLoc;
	FILE *fp;
	fp = fopen("nodeLatLon2.txt","r");
	while((feof(fp)==0))
	{
		fscanf(fp,"%lf %lf\n",&tmpLoc.lat,&tmpLoc.lon);
		if((tmpLoc.lat < 999.99) && (tmpLoc.lon < 999.99))
			wayPts->push_back(tmpLoc);
		else
		{
			wayPtsGrp->push_back(*wayPts);
			wayPts->clear();
		}
	}
	fclose(fp);
}

void GPSProcessing::gpsMapRecenter(vector <vector<Point2f>> *tngtPrjwayGrp,Mat image)
{

	Mat offset(3, 3, CV_32F, Scalar(0));
	vector<cv::Point2f>tmpTrnwayPts;     
	vector <vector<Point2f>> tmpTrnwayGrp;

	//offset matrix. This is to transform the negative points to positive
	offset.at<float>(0,0) = 1;
	offset.at<float>(1,1) = 1;
	offset.at<float>(2,2) = 1;
	offset.at<float>(0,2) = image.cols/2;
	offset.at<float>(1,2) = image.rows/2;
 
	for(int i =0; i < tngtPrjwayGrp->size(); i++)
	{
		tmpTrnwayPts.clear();   
		cv::perspectiveTransform(tngtPrjwayGrp->at(i),tmpTrnwayPts,offset);
		tmpTrnwayGrp.push_back(tmpTrnwayPts);
	}

	image.setTo(cv::Scalar(0,0,0));
	for (int i=0;i<tmpTrnwayGrp.size();i++)
	{
		tmpTrnwayPts.clear();
		tmpTrnwayPts = tmpTrnwayGrp.at(i);
  		for (int j=0;j<(tmpTrnwayPts.size()-1);j++)
		{
			line(image,tmpTrnwayPts.at(j),tmpTrnwayPts.at(j+1),Scalar(255,255,255),2,8,0);
			circle(image,tmpTrnwayPts.at(j+1),2,Scalar(0,255,0),-1,8,0);
		//	namedWindow("gpsMap");
		//	imshow("gpsMap",image);
		}	
		//waitKey(0);

	} 
	circle(image,Point2f(image.cols/2,image.rows/2),2,Scalar(0,0,255),-1,8,0);
}



void GPSProcessing::drawGPSMap(loc mapCenter,bool *readMapFlag,Mat mapImage,vector <loc> *wayPts,vector <vector<loc>> *wayGrp)
{
	vector <Point2f> cartWayPts;
	vector <vector<Point2f>> cartWayPtsGrp;
	Point2f cartLastPOS;
	Point2f pt1,pt2;
	
	if(*readMapFlag == true)//this is to read the map for the first time
	{	
		wayPts->clear();
		wayGrp->clear();
		mapRead(wayPts,wayGrp);
		*readMapFlag = false;
	}
	else
	{
		cartWayPts.clear();
		cartWayPtsGrp.clear();
		latlon2Cart_mlti_pt(wayPts,wayGrp,&cartWayPts,&cartWayPtsGrp,mapCenter);
		//the tangent plane has points with mapCenter at he origin (0,0)
		//so it has to be brought to the center of the image
		gpsMapRecenter(&cartWayPtsGrp,mapImage);
		//draw the last point
		cartLastPOS = latlon2Cart_1_pt(lastPOS,mapCenter);
		//drawing the gps trajectory that the car travels
		for(unsigned int i=0;i!=gpsTrack.size()-1;i++)
		{
			if((gpsTrack.at(i).lat!=gpsTrack.at(i+1).lat)&&(gpsTrack.at(i).lon!=gpsTrack.at(i+1).lon)
				&&(gpsTrack.at(i).lat!=0)&&(gpsTrack.at(i).lon!=0)
				&&(gpsTrack.at(i+1).lat!=0)&&(gpsTrack.at(i+1).lon!=0))
			{
				pt1=latlon2Cart_1_pt(gpsTrack.at(i),mapCenter);
				pt2=latlon2Cart_1_pt(gpsTrack.at(i+1),mapCenter);
				pt1.x = pt1.x+ mapImage.cols/2;
				pt1.y = pt1.y+ mapImage.rows/2;
				pt2.x = pt2.x+ mapImage.cols/2;
				pt2.y = pt2.y+ mapImage.rows/2;
				cv::line(mapImage,pt1,pt2,Scalar(255,0,255),2,8,0);
			}
		}
		circle(mapImage,Point2f(cartLastPOS.x+mapImage.cols/2,cartLastPOS.y+mapImage.rows/2),4,Scalar(255,0,255),1,8,0);

		namedWindow("gpsMap");
		imshow("gpsMap",mapImage);
		
	}
}

/*
void GPSProcessing::startGPS(void* param)
{
	
	switchOFF = false;
	int idx=0;
	string line1 = "";
	string line2 = "";
	const char* c_line;
	double tmp1 = 0;
	double m_lat = 0;
	double m_lon = 0;
	double m_time1 = 0;
	double m_time2 = 0;
	double delay;
	loc myLoc;
	vector <loc> wayPts;vector <vector<loc>> wayPtsGrp;
	bool readMapFlag = true;
	cv::Mat gpsMap(300,300,CV_32FC3,cv::Scalar(0));

	ifstream gpsLatFile("Data//ANDGPSLA2014-10-30-09-42-24.csv");
	ifstream gpsLonFile("Data//ANDGPSLO2014-10-30-09-42-24.csv");
	
	//read the initial sensor timestamp--------------------
	if(!getline(gpsLatFile, line1))
		_endthread();
	else
	{
		c_line =line1.c_str();
		sscanf_s(c_line,"%lf,%lf,%lf",&tmp1,&m_time1,&m_lat);
	}

	if(!getline(gpsLonFile, line2))
		_endthread();
	else
	{
		c_line =line2.c_str();
		sscanf_s(c_line,"%lf,%lf,%lf",&tmp1,&m_time1,&m_lon);
	}
	//------------------------------------------------------
	time_t t = std::time(0);
	g_timestamp = 0.404490310;
	double milliseconds;
	boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
	boost::posix_time::time_duration td = now.time_of_day();
	milliseconds=(td.total_milliseconds())/86400000.0;
	double timestamp_offset = milliseconds - g_timestamp;
	

	while(getline(gpsLatFile, line1) && (getline(gpsLonFile, line2)))
	{
		//read the GPS data
		c_line =line1.c_str();
		sscanf_s(c_line,"%lf,%lf,%lf",&tmp1,&m_time2,&m_lat);
		c_line =line2.c_str();
		sscanf_s(c_line,"%lf,%lf,%lf",&tmp1,&m_time2,&m_lon);

		//sync
		
		while(g_timestamp<m_time2)
		{
			now = boost::posix_time::microsec_clock::local_time();
			td = now.time_of_day();
			g_timestamp = ((td.total_milliseconds())/86400000.0)-timestamp_offset;
		}

		cout <<m_time2<<" "<<g_timestamp<<" "<<CAMtimestamp<< endl;
		//delay is calculated as per the timestamp
		delay = (m_time2-m_time1)*86400000;
		//cout << delay <<endl;
		myLoc.lat = m_lat;
		myLoc.lon = m_lon;
		//mapMatch();
		//drawGPSMap(myLoc,&readMapFlag,gpsMap,&wayPts,&wayPtsGrp);
		//Sleep(delay); //wait in milli seconds
		waitKey(1);
		m_time1 = m_time2;
		if(switchOFF)
			break;
	}
	_endthread();
}
	

void GPSProcessing::beginGPSProcessing()
{
	void* param=0;
	_beginthread(startGPS,0,param);
}

void GPSProcessing::stopGPSProcessing()
{
	switchOFF = true;
}
*/

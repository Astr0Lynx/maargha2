#include "ACCProcessing.h"
#include "global.h"
#include <deque>

//Global Variables
static bool switchOFF;
extern sensorData liveData;
extern sensorData prevData;
extern bool TRAIN;
extern int roadCondition;

using namespace std;

#define K_NN 5
std::deque<loc>gpsTrack;
std::deque<double> ACC_Values;
std::deque<double> DIST_Values;
std::deque<double> ACC_Values_s;
extern double RMSD;
extern vector <vector <float>> trainingDataSet;
extern vector <float> trainingDataElement;
vector <float> liveDataElement;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ACCProcessing::ACCProcessing()
{
}

ACCProcessing::~ACCProcessing()
{
}

void plotAcc(Mat accPlot)
{
	if(ACC_Values.empty())
		return;
	accPlot.setTo(Scalar(0));
	for(int i=0;i<ACC_Values.size()-1;i++)
	{
		cv::line(accPlot,cv::Point2f(i,(ACC_Values.at(i)*10 + (accPlot.rows)/2)),cv::Point2f(i,ACC_Values.at(i+1)*10 + (accPlot.rows)/2),Scalar(255,255,255),1,8,0);
	}
	cv::imshow("Acc_Plot",accPlot);
}

double gpsDistance(loc presPOS, loc prevPOS) 
{
	if((presPOS.lat == prevPOS.lat) && (presPOS.lon == prevPOS.lon))
		return 0;
    double earthRadius = 6371; //kilometers
	double dLat = DEG2RAD((prevPOS.lat-presPOS.lat));
    double dLng = DEG2RAD((prevPOS.lon-presPOS.lon));
    double a = sin(dLat/2) * sin(dLat/2) +
               cos(DEG2RAD(presPOS.lat)) * cos(DEG2RAD(prevPOS.lat)) *
               sin(dLng/2) * sin(dLng/2);
    double c = 2 * atan2(sqrt(a), sqrt(1-a));
    double dist = (earthRadius * c);
    return dist*1000;
}


void ACCProcessing::processACC(Mat *accPlot)
{

	static double sumSqr=0;
	double intraPtDist=0;
	static loc presPOS,prevPOS;
	static double distTvld=0;
	//-----------------------------------------------------------------
	plotAcc(*accPlot);

	//distance calculation-----------------------------------------
	prevPOS.lat = presPOS.lat;prevPOS.lon = presPOS.lon;
	presPOS.lat = liveData.lat;presPOS.lon = liveData.lon;
	intraPtDist = gpsDistance(presPOS, prevPOS);
	if(intraPtDist>10000)
		return;
	distTvld = distTvld + intraPtDist;
			
	//Finding RMSD-----------------------------------------------------
	ACC_Values.push_back(liveData.accG);//1
	ACC_Values_s.push_back(liveData.accG * liveData.accG);//2
	sumSqr = sumSqr + ACC_Values_s.back();
	//one of the feature vector element
	RMSD = sqrt(sumSqr / ACC_Values_s.size());
	cout <<"RMSD: "<<RMSD<<"Speed"<<liveData.speed<<endl;
	

	DIST_Values.push_back(intraPtDist);//3
	gpsTrack.push_back(presPOS);//4
	//if (distTvld > X) reduce the buffer content------------------
	if (distTvld > DIST_THRESH_M)
	{
		/*--------------------------------------------------------
		//gps debug
		double gpsDist=0;
		for(unsigned int i=0;i<gpsTrack.size()-1;i++)
		{
			if((gpsTrack.at(i).lat!=gpsTrack.at(i+1).lat)&&(gpsTrack.at(i).lon!=gpsTrack.at(i+1).lon)
				&&(gpsTrack.at(i).lat!=0)&&(gpsTrack.at(i).lon!=0)
				&&(gpsTrack.at(i+1).lat!=0)&&(gpsTrack.at(i+1).lon!=0))
			{
				gpsDist= gpsDist+gpsDistance(gpsTrack.at(i), gpsTrack.at(i+1));
			}
		}
		cout <<"gps dist"<<gpsDist<<endl;
		//--------------------------------------------------------*/
		while (distTvld > DIST_THRESH_M)
		{
			distTvld = distTvld - DIST_Values.front();
			sumSqr   = sumSqr - ACC_Values_s.front();		
			gpsTrack.pop_front();
			ACC_Values.pop_front();
			ACC_Values_s.pop_front();
			DIST_Values.pop_front();
		}
	}
	//in case the buffer overflows
	if(gpsTrack.size()>BUF_SIZE)
	{
		distTvld = distTvld - DIST_Values.front();
		sumSqr   = sumSqr - ACC_Values_s.front();
		gpsTrack.pop_front();
		ACC_Values.pop_front();
		ACC_Values_s.pop_front();
		DIST_Values.pop_front();
	}
}

void ACCProcessing::train()
{
	TRAIN=false;
	char buff[100];
	float tempVec[3];
	FILE *fp;
	fp=fopen("my_accleration.txt","a");
	//if (!fp.isOpened()) {std::cout << "unable to open file storage!" << std::endl; return;}
	sprintf_s(buff,"%f %lf %d",RMSD,liveData.speed,roadCondition);
	tempVec[0]=RMSD;
	tempVec[1]=liveData.speed;
	tempVec[2]=roadCondition;
	for(unsigned int i=0;i<3;i++){
		trainingDataElement.push_back(tempVec[i]);}

		trainingDataSet.push_back(trainingDataElement);
		trainingDataElement.clear();


	fprintf(fp,"%s \n",buff);
	fclose(fp);
}

bool compareVectors(vector <float> a,vector <float> b)
{
	return (a.at(0)<b.at(0));
}

void ACCProcessing::classify()
{	
	//cout<<"in classifier";
	float eucliDist=0;
	vector <float> dist_and_class;
	vector <vector <float>> all_dist_and_class;
	all_dist_and_class.clear();
	liveDataElement.clear();
	liveDataElement.push_back(RMSD);
	liveDataElement.push_back(liveData.speed);
	//liveDataElement.push_back(0);
//	cout<<trainingDataSet.size();
	for(unsigned int i=0;i<trainingDataSet.size();i++)
	{
		trainingDataElement = trainingDataSet.at(i);
		eucliDist = CalculateEuclidean(trainingDataElement,liveDataElement);
		dist_and_class.push_back(eucliDist);
		dist_and_class.push_back(trainingDataElement.at(2));
		all_dist_and_class.push_back(dist_and_class);
		dist_and_class.clear();
	}
	//sort the all_dist_and_class vector based on the distance(first vector element)
	std::sort(all_dist_and_class.begin(),all_dist_and_class.end(),compareVectors);
	int road_class[4];
	for(unsigned int i=0;i<2;i++)
		road_class[i]=0;
	for (unsigned int i=0;i<K_NN;i++)
	{
		//cout<<(int)all_dist_and_class.at(i).at(1)<<endl;
		switch((int)all_dist_and_class.at(i).at(1))
		{
		case 1:
			road_class[0]++;
			break;
		case 2:
			road_class[1]++;
			break;
		case 3:
			road_class[2]++;
			break;
		default:
			cout<<"something wrong"<<endl;
		}
	}

	int largest=0;
	int idx=0;
	for(unsigned int i=0;i<2;i++)
		if(road_class[i]>largest)
		{
			largest = road_class[i];
			idx = i;
		}
	roadCondition = idx;
	cout<<'\n'<<"condi"<<roadCondition;
}

float ACCProcessing::CalculateEuclidean(vector<float> vec1,vector<float> vec2)
{
	float distance = 0;

	for (unsigned int i=0;i<vec2.size();i++)//vec1 will have one extra element(class)
	{
		distance = distance  + pow(vec1.at(i)-vec2.at(i),2);
	}
	return sqrt(distance);
}




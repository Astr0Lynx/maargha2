// GPSInfo.h: interface for the GPSInfo class.
//
//////////////////////////////////////////////////////////////////////
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <process.h>
#include <iostream>
#include <fstream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <Windows.h>
#include <stdio.h>
#include "global.h"
using namespace std;
using namespace cv;



class GPSProcessing
{
private:
	Point2d GPSProcessing::tngtPlaneProj(loc mapCenter,loc ltlnPt);
	void GPSProcessing::latlon2Cart_mlti_pt(vector <loc> *wayPts,vector <vector<loc>> *wayGrp,vector <Point2f> *cartWayPts,vector <vector<Point2f>> *cartWayPtsGrp,loc mapCenter);
	Point2d GPSProcessing::latlon2Cart_1_pt(loc ltlnPt,loc mapCenter);
	void GPSProcessing::mapRead(vector <loc> *wayPts,vector <vector<loc>> *wayPtsGrp);
	void GPSProcessing::gpsMapRecenter(vector <vector<Point2f>> *tngtPrjwayGrp,Mat image);
public:
	GPSProcessing();
	virtual ~GPSProcessing();
	void GPSProcessing::drawGPSMap(loc mapCenter,bool *readMapFlag,Mat mapImage,vector <loc> *wayPts,vector <vector<loc>> *wayGrp);
};


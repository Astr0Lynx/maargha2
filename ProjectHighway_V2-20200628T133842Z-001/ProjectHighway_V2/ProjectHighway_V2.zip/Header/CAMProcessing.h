#include <process.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp>


class CAMProcessing
{
private:
	
	
public:
	CAMProcessing();
	virtual ~CAMProcessing();	
	cv::Mat Get_subImage(cv::Mat image);
	void updateSampleCount(void);
	void readSampleCount(void);
	void train(void);
	void classify(double lat, double lon);
};